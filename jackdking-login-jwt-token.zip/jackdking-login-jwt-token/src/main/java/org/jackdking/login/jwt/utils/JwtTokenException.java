package org.jackdking.login.jwt.utils;

public class JwtTokenException extends Exception{
	

	public JwtTokenException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	
	
}
